package com.example.retrofit

import retrofit2.Call
import retrofit2.http.GET

// Define your API interface
interface ApiInterface {
    @GET("stats/allstarballotpredictor") // Use the correct endpoint
    fun getExampleData(): Call<ExampleResponse>
}